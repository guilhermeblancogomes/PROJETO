export class classificacaogeral {

    equipe: string;
    pontosGanhos: number;
    jogos: number;
    vitorias: number;
    empates: number;
    derrotas: number;
    golsPro: number;
    golsContra: number;
    saldoGols: number;
    cartoesAmarelos: number;
    cartoesVermelhos: number



    constructor( equipe: string,
        pontosGanhos: number,
        jogos: number,
        vitorias: number,
        empates: number,
        derrotas: number,
        golsPro: number,
        golsContra: number,
        saldoGols: number,
        cartoesAmarelos: number,
        cartoesVermelhos: number
        ) {

        this.pontosGanhos = pontosGanhos;
        this.jogos = jogos;
        this.vitorias = vitorias;
        this.empates = empates;
        this.derrotas = derrotas;
        this.golsPro = golsPro;
        this.golsContra = golsContra;
        this.saldoGols = saldoGols;
        this.golsContra = golsContra;
        this.cartoesAmarelos = cartoesAmarelos;
        this.cartoesVermelhos = cartoesVermelhos;
        
    }
}

