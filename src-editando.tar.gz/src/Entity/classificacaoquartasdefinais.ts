export class classificacaoquartasdefinais {

    nome: string;
    gols: number;
    equipe: string;
    numero: number;
    posicao: string;
    categoria: string;
    cartoesAmarelos: number;
    cartoesVermelhos: number



    constructor(nome: string,
        gols: number,
        equipe: string,
        numero: number,
        posicao: string,
        categoria: string,
        cartoesAmarelos: number,
        cartoesVermelhos: number
        ) {

        this.gols = gols;
        this.equipe = equipe;
        this.numero = numero;
        this.posicao = posicao;
        this.categoria = categoria;
        this.cartoesAmarelos = cartoesAmarelos;
        this.categoria = categoria;
        this.cartoesAmarelos = cartoesAmarelos;
        this.cartoesVermelhos = cartoesVermelhos;
        
    }
}

