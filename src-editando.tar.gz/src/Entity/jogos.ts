export class jogos {

    data: string;
    horario: string;
    equipe1: string;
    golsEquipe1: number;
    equipe2: string;
    golsEquipe2: number;
    categoria: string;
    cartoesAmarelos: number;
    cartoesVermelhos: number;
    totalCartoes: number;
    arbitro: string;
    assistente1: string;
    assistente2: string;
    notaArbitroMedia: number;
    notaArbitroEquipe1: number;
    notaArbitroEquipe2: number;
    rodada: number;
    turno: number;
    vencedor: string;


    constructor(data: string,
        horario: string,
        equipe1: string,
        golsEquipe1: number,
        equipe2: string,
        golsEquipe2: number,
        categoria: string,
        cartoesAmarelos: number,
        cartoesVermelhos: number,
        totalCartoes: number,
        arbitro: string,
        assistente1: string,
        assistente2: string,
        notaArbitroMedia: number,
        notaArbitroEquipe1: number,
        notaArbitroEquipe2: number,
        rodada: number,
        turno: number,
        vencedor: string) {

        this.data = data;
        this.horario = horario;
        this.equipe1 = equipe1;
        this.golsEquipe1 = golsEquipe1;
        this.equipe2 = equipe2;
        this.golsEquipe2 = golsEquipe2;
        this.categoria = categoria;
        this.cartoesAmarelos = cartoesAmarelos;
        this.cartoesVermelhos = cartoesVermelhos;
        this.totalCartoes = totalCartoes;
        this.arbitro = arbitro;
        this.assistente1 = assistente1;
        this.assistente2 = assistente2;
        this.notaArbitroMedia = notaArbitroMedia;
        this.notaArbitroEquipe1 = notaArbitroEquipe1;
        this.notaArbitroEquipe2 = notaArbitroEquipe2;
        this.rodada = rodada;
        this.turno = turno;
        this.vencedor = vencedor;
    }
}

