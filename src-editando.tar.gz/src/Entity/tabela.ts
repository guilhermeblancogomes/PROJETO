export class tabela {

    rodada: number;
    turno: number;
    data: number;
    horario: number;
    equipe1: string;
    equipe2: string;
    categoria: string;




    constructor(rodada: number,
        turno: number,
        data: number,
        horario: number,
        equipe1: string,
        equipe2: string,
        categoria: string) {

        this.rodada = rodada;    
        this.turno = turno;
        this.data = data;
        this.horario = horario;
        this.equipe1 = equipe1;
        this.equipe2 = equipe2;
        this.categoria = categoria;
     
        
    }
}

