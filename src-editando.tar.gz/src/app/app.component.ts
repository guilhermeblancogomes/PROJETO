import { Component, ViewChild } from '@angular/core';
import { Nav, Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { DatabaseProvider } from '../providers/data-base/data-base';
import { JogosPage } from '../pages/jogos/jogos';
import { SumulaPage } from '../pages/sumula/sumula';
// aqui você vai importar as outras paginas que você vai criar, exemplo:
import { ArtilheirosPage } from '../pages/artilheiros/artilheiros';
import {TabelaPage} from '../pages/tabela/tabela';
import {ClassificacaoGeralPage} from '../pages/classificacaogeral/classificacaogeral';
import {CartoesAmarelosPage} from '../pages/cartoesamarelos/cartoesamarelos';
import {CartoesVermelhosPage} from '../pages/cartoesvermelhos/cartoesvermelhos';
//import {ClassificacaoQuartasDeFinaisPage} from '../pages/classificacaoquartasdefinais/classificacaoquartasdefinais';



@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;
// aqui é a primeira tela que vai abrir
  rootPage: any = JogosPage;

  pages: Array<{icon:string , title: string, component: any }>;

  constructor(public platform: Platform, public statusBar: StatusBar,
    public splashScreen: SplashScreen, dbProvider: DatabaseProvider) {
    this.initializeApp();

    // used for an example of ngFor and navigation
    this.pages = [
      //aqui voce vai listar os itens do menu
      {icon: "ios-football", title: 'Jogos', component: JogosPage },
      {icon: "ios-list", title: 'Artilheiros', component: ArtilheirosPage },
      {icon: "ios-analytics", title: 'Tabelas', component: TabelaPage},
      {icon: "logo-buffer", title: 'Classificação', component: ClassificacaoGeralPage},
      //{title: 'ClassificacaoQuartasDeFinais', component: ClassificacaoQuartasDeFinaisPage},
      {icon: "ios-football", title: 'Cartões Amarelos', component: CartoesAmarelosPage},
      {icon: "ios-football" ,title: 'Cartões Vermelhos', component: CartoesVermelhosPage}
      //{title: 'Suspensos', component: SuspensosPage}
      

    ];

  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }

  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.nav.setRoot(page.component);
  }
}
