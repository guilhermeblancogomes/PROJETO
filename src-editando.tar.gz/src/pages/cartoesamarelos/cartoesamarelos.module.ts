import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CartoesAmarelosPage } from './cartoesamarelos';
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@NgModule({
  declarations: [
    CartoesAmarelosPage,
  ],
  imports: [
    IonicPageModule.forChild(CartoesAmarelosPage),
  ],
})

@Component({
  selector: 'page-cartoesamarelos',
  templateUrl: 'cartoesamarelos.html'
})
export class CartoesAmarelosPageModule {

}
