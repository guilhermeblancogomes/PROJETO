import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ClassificacaoGeralPage } from './classificacaogeral';
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@NgModule({
  declarations: [
    ClassificacaoGeralPage,
  ],
  imports: [
    IonicPageModule.forChild(ClassificacaoGeralPage),
  ],
})

@Component({
  selector: 'page-classificacaogeral',
  templateUrl: 'classificacaogeral.html'
})
export class ClassificacaoGeralPageModule {

}
