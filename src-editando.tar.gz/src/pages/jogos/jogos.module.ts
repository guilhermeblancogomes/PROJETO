import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { JogosPage } from './jogos';
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@NgModule({
  declarations: [
    JogosPage,
  ],
  imports: [
    IonicPageModule.forChild(JogosPage),
  ],
})

@Component({
  selector: 'page-jogos',
  templateUrl: 'jogos.html'
})
export class JogosPageModule {

}
