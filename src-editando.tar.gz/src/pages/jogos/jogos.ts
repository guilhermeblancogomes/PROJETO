import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { JogosProvider } from '../../providers/jogos/jogos';
import { ProviderGeral } from '../../providers/provider/provider';
import { jogos } from '../../Entity/jogos';
import { SumulaPage } from '../sumula/sumula';

@Component({
  selector: 'page-jogos',
  templateUrl: 'jogos.html',
})
export class JogosPage {

  realizado = "master";
  public lista = new Array<any>();
  public listaMaster = new Array<any>();
  public listaSenior = new Array<any>();

  constructor(public navCtrl: NavController, private provider: ProviderGeral, public susp: JogosProvider) {
  }
  ionViewDidLoad() {
    this.provider.getJogos().subscribe(
      data => {
        const response = (data as any);
        const objeto_retorno = JSON.parse(response._body);
        //this.susp.inserir(objeto_retorno);
        this.lista = objeto_retorno;
        for (let item of this.lista) {
          if (item.categoria == 'Master') {
            this.listaMaster.push(item);
          } else {
            this.listaSenior.push(item);
          }

        }
      }

    )
  }
  public jogos(jogo: jogos): void{
    this.navCtrl.push(SumulaPage, { jogoSelecionado: jogo });
  }
}
