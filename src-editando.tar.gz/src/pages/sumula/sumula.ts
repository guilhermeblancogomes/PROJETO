import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { jogos } from '../../Entity/jogos';


@IonicPage()
@Component({
  selector: 'page-sumula',
  templateUrl: 'sumula.html',
})
export class SumulaPage {
  public jogo : jogos;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.jogo = this.navParams.get("jogoSelecionado");

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SumulaPage');
    console.log(this.jogo);
  }

}
