import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TabelaPage } from './tabela';
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@NgModule({
  declarations: [
    TabelaPage,
  ],
  imports: [
    IonicPageModule.forChild(TabelaPage),
  ],
})

@Component({
  selector: 'page-tabela',
  templateUrl: 'tabela.html'
})
export class TabelaPageModule {

}
