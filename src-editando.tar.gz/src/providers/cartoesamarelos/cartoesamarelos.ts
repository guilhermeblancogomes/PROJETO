import { Injectable } from '@angular/core';
import { DatabaseProvider } from '../data-base/data-base';
import { cartoesamarelos } from '../../Entity/cartoesamarelos';
import { SQLiteObject } from '@ionic-native/sqlite';

@Injectable()
export class CartoesAmarelosProvider {

  constructor(private dbProvider: DatabaseProvider) {
    console.log('Hello CartoesAmarelosProvider Provider');
  }

 
    public inserir(cartoesamarelos: cartoesamarelos) {
      return this.dbProvider.openDatabase().then((db: SQLiteObject) => {
        let sql = 'insert into cartoesamarelos (equipe) values (?), (numero) values (?), (jogador) values (?), (data) values (?), (tempo) values (?), (adversario) values (?), (arbitro) values (?),';
        let parametros = [cartoesamarelos.equipe, cartoesamarelos.numero, cartoesamarelos.jogador, cartoesamarelos.data, cartoesamarelos.tempo, cartoesamarelos.adversario, cartoesamarelos.arbitro];
        return db.executeSql(sql, parametros).catch((e) => {
      });
    }).catch((e) => {
      console.log(e);
    });
  }

  public listar() {
    //abre a base
    return this.dbProvider.openDatabase()
      .then((db: SQLiteObject) => {
        //faz o select
        let sql = "SELECT * FROM cartoesamarelos";
        return db.executeSql(sql, []).
          then((data: any) => {
            //se tiver alguma linha na tabela
            if (data.rows.lenght > 0) {
              let cartoesamarelos: cartoesamarelos[] = [];
              //pega cada linha e coloca num vetor
              for (let i = 0; i < data.rows.lenght; i++) {
                cartoesamarelos.push(data.rows.item(i));
              }
              return cartoesamarelos;
            }
            else
              //devolve vetor vazio se a tabela estiver vazia
              return [];
          });

      })
  }
}
