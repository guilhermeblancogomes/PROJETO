import { Injectable } from '@angular/core';
import { DatabaseProvider } from '../data-base/data-base';
import { cartoesvermelhos } from '../../Entity/cartoesvermelhos';
import { SQLiteObject } from '@ionic-native/sqlite';

@Injectable()
export class CartoesVermelhosProvider {

  constructor(private dbProvider: DatabaseProvider) {
    console.log('Hello CartoesVermelhosProvider Provider');
  }

 
    public inserir(cartoesvermelhos: cartoesvermelhos) {
      return this.dbProvider.openDatabase().then((db: SQLiteObject) => {
        let sql = 'insert into cartoesvermelhos (equipe) values (?), (numero) values (?), (jogador) values (?), (data) values (?), (tempo) values (?), (adversario) values (?), (arbitro) values (?),';
        let parametros = [cartoesvermelhos.equipe, cartoesvermelhos.numero, cartoesvermelhos.jogador, cartoesvermelhos.data, cartoesvermelhos.tempo, cartoesvermelhos.adversario, cartoesvermelhos.arbitro];
        return db.executeSql(sql, parametros).catch((e) => {
      });
    }).catch((e) => {
      console.log(e);
    });
  }

  public listar() {
    //abre a base
    return this.dbProvider.openDatabase()
      .then((db: SQLiteObject) => {
        //faz o select
        let sql = "SELECT * FROM cartoesvermelhos";
        return db.executeSql(sql, []).
          then((data: any) => {
            //se tiver alguma linha na tabela
            if (data.rows.lenght > 0) {
              let cartoesvermelhos: cartoesvermelhos[] = [];
              //pega cada linha e coloca num vetor
              for (let i = 0; i < data.rows.lenght; i++) {
                cartoesvermelhos.push(data.rows.item(i));
              }
              return cartoesvermelhos;
            }
            else
              //devolve vetor vazio se a tabela estiver vazia
              return [];
          });

      })
  }
}
