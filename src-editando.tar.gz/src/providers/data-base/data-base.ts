import { Injectable } from '@angular/core';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';

@Injectable()
export class DatabaseProvider {

  constructor(private db: SQLite) {
    console.log('Hello DatabaseProvider Provider');
  }

  openDatabase() {
    return this.db.create({
      name: "projeto.db",
      location: "default"
    })
  }

  createTabelaSuspensos(db: SQLiteObject) {
    let sql: string = 'CREATE TABLE IF NOT EXISTS tabela (' +
      'id integer primary key AUTOINCREMENT NOT NULL,' +
      'equipe TEXT, jogador TEXT,' +
      'numero TEXT,' +
      'categoria TEXT,' +
      'criterio TEXT,' +
      'jogos TEXT,' +
      'motivo TEXT,)' ;
    db.executeSql(sql, {});
  }
  createTabelaTabela(db: SQLiteObject) {
    let sql: string = 'CREATE TABLE IF NOT EXISTS tabela (' +
      'id integer primary key AUTOINCREMENT NOT NULL,' +
      'rodada TEXT, turno TEXT,' +
      'data TEXT,' +
      'horario TEXT,' +
      'equipe1 TEXT,' +
      'equipe2 TEXT,' +
      'categoria TEXT,)' ;
    db.executeSql(sql, {});
  }

  createTabelaCartoesAmarelos(db: SQLiteObject) {
    let sql: string = 'CREATE TABLE IF NOT EXISTS tabela (' +
      'id integer primary key AUTOINCREMENT NOT NULL,' +
      'equipe TEXT, numero TEXT,' +
      'jogador TEXT,' +
      'data TEXT,' +
      'tempo TEXT,' +
      'adversario TEXT,' +
      'arbitro TEXT,)' ;
    db.executeSql(sql, {});
  }

  createTabelaCartoesVermelhos(db: SQLiteObject) {
    let sql: string = 'CREATE TABLE IF NOT EXISTS tabela (' +
      'id integer primary key AUTOINCREMENT NOT NULL,' +
      'equipe TEXT, numero TEXT,' +
      'jogador TEXT,' +
      'data TEXT,' +
      'tempo TEXT,' +
      'adversario TEXT,' +
      'arbitro TEXT,)' ;
    db.executeSql(sql, {});
  }

  createTabelaClassificacaoGeral(db: SQLiteObject) {
    let sql: string = 'CREATE TABLE IF NOT EXISTS classificacaogeral (' +
      'id integer primary key AUTOINCREMENT NOT NULL,' +
      'equipe TEXT, pontosGanhos TEXT,' +
      'jogos TEXT,' +
      'vitorias TEXT,' +
      'empates TEXT,' +
      'derrotas TEXT,' +
      'golsPro TEXT,' +
      'golsContra TEXT,' +
      'saldoGols TEXT,' +
      'cartoesAmarelos TEXT,' +
      'cartoesVermelhos TEXT )';
    db.executeSql(sql, {});
  }

  createTabelaArtilheiros(db: SQLiteObject) {
    let sql: string = 'CREATE TABLE IF NOT EXISTS artilheiros (' +
      'id integer primary key AUTOINCREMENT NOT NULL,' +
      'nome TEXT, gols TEXT,' +
      'equipe TEXT,' +
      'numero TEXT,' +
      'posicao TEXT,' +
      'categoria TEXT,' +
      'cartoesAmarelos TEXT,' +
      'cartoesVermelhos TEXT )';
    db.executeSql(sql, {});
  }

 

  createTabelaJogos(db: SQLiteObject) {
    let sql: string = 'CREATE TABLE IF NOT EXISTS jogos (' +
      'id integer primary key AUTOINCREMENT NOT NULL,' +
      'data TEXT,' +
      'horario TEXT,' +
      'equipe1 TEXT,' +
      'equipe2 TEXT,' +
      'golsEquipe1 TEXT,' +
      'golsEquipe2 TEXT,' +
      'cartoesVermelhos TEXT,' +
      'cartoesAmarelos TEXT,' +
      'totalCartoes TEXT,' +
      'categoria TEXT,' +
      'assistente1 TEXT,' +
      'assistente2 TEXT,' +
      'notaArbitroMedia TEXT,' +
      'notaArbitroEquipe1 TEXT,' +
      'notaArbitroEquipe2 TEXT,' +
      'rodada TEXT,' +
      'turno TEXT,' +
      'vencedor TEXT,' +
      'arbitro TEXT)';
    db.executeSql(sql, {}); 
  }

  createDatabase() {
    return this.openDatabase()
      .then((db: SQLiteObject) => {
        
          this.createTabelaJogos(db),
          this.createTabelaArtilheiros(db);
          this.createTabelaTabela(db);
          this.createTabelaClassificacaoGeral(db);
          this.createTabelaSuspensos(db);
          this.createTabelaCartoesAmarelos(db);
          this.createTabelaCartoesVermelhos
      });
  }
}
