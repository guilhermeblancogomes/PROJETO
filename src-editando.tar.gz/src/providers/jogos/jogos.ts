import { Injectable } from '@angular/core';
import { DatabaseProvider } from '../data-base/data-base';
import { jogos } from '../../Entity/jogos';
import { SQLiteObject } from '@ionic-native/sqlite';

@Injectable()
export class JogosProvider {

  constructor(private dbProvider: DatabaseProvider) {
    console.log('Hello JogosProvider Provider');
  }

  public inserir(jogos: jogos) {
    return this.dbProvider.openDatabase().then((db: SQLiteObject) => {
      let sql = 'insert into jogos (data) values (?), (horario) values (?), (equipe1) values (?), (golsEquipe1) values (?), (equipe2) values (?), (golsEquipe2) values (?), (categoria) values (?),(cartoesAmarelos) values (?), (cartoesVermelhos) values (?), (totalCartoes) values (?), (arbitro) values (?), (assistente1) values (?), (assistente2) values (?),(notaArbitroMedia) values (?),(notaArbitroEquipe1) values (?),(notaArbitroEquipe2) values (?),(rodada) values (?),(turno) values (?), (vencedor) values (?), ';
      let parametros = [jogos.data, jogos.horario, jogos.equipe1, jogos.golsEquipe1, jogos.equipe2, jogos.golsEquipe2, jogos.categoria, jogos.cartoesAmarelos, jogos.cartoesVermelhos, jogos.totalCartoes, jogos.categoria, jogos.arbitro, jogos.assistente1, jogos.assistente2, jogos.notaArbitroMedia, jogos.notaArbitroEquipe1, jogos.notaArbitroEquipe2, jogos.rodada, jogos.turno, jogos.vencedor];
      return db.executeSql(sql, parametros).catch((e) => {
        console.log(e);
      });
    }).catch((e) => {
      console.log(e);
    });
  }

  public listar() {
    //abre a base
    return this.dbProvider.openDatabase()
      .then((db: SQLiteObject) => {
        //faz o select
        let sql = "SELECT * FROM jogos";
        return db.executeSql(sql, []).
          then((data: any) => {
            //se tiver alguma linha na tabela
            if (data.rows.lenght > 0) {
              let jogos: jogos[] = [];
              //pega cada linha e coloca num vetor
              for (let i = 0; i < data.rows.lenght; i++) {
                jogos.push(data.rows.item(i));
              }
              return jogos;
            }
            else
              //devolve vetor vazio se a tabela estiver vazia
              return [];
          });

      })
  }
}
