import { Injectable } from '@angular/core';
import { DatabaseProvider } from '../data-base/data-base';
import { suspensos } from '../../Entity/suspensos';
import { SQLiteObject } from '@ionic-native/sqlite';

@Injectable()
export class SuspensosProvider {

  constructor(private dbProvider: DatabaseProvider) {
    console.log('Hello SuspensosProvider Provider');
  }

 
    public inserir(suspensos: suspensos) {
      return this.dbProvider.openDatabase().then((db: SQLiteObject) => {
        let sql = 'insert into suspensos (equipe) values (?), (jogador) values (?), (numero) values (?), (categoria) values (?), (criterio) values (?), (jogos) values (?), (motivo) values (?),';
        let parametros = [suspensos.equipe, suspensos.jogador, suspensos.numero, suspensos.categoria, suspensos.criterio, suspensos.jogos, suspensos.motivo];
        return db.executeSql(sql, parametros).catch((e) => {
      });
    }).catch((e) => {
      console.log(e);
    });
  }

  public listar() {
    //abre a base
    return this.dbProvider.openDatabase()
      .then((db: SQLiteObject) => {
        //faz o select
        let sql = "SELECT * FROM suspensos";
        return db.executeSql(sql, []).
          then((data: any) => {
            //se tiver alguma linha na tabela
            if (data.rows.lenght > 0) {
              let suspensos: suspensos[] = [];
              //pega cada linha e coloca num vetor
              for (let i = 0; i < data.rows.lenght; i++) {
                suspensos.push(data.rows.item(i));
              }
              return suspensos;
            }
            else
              //devolve vetor vazio se a tabela estiver vazia
              return [];
          });

      })
  }
}
